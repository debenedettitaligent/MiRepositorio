from setuptools import setup

setup(
        name = "TuModeloDeClientes+DeBenedetti",
        version = "1.0",
        description = "Clase Cliente",
        author = "Leandro De Benedetti",
        author_email = "leandrodb@live.com.ar",
        packages = ["TuModeloDeClientes+DeBenedetti"])